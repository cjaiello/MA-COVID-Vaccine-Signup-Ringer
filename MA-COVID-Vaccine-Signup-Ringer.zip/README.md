# Chrome Extension for Getting an Audio Alert When It's Your Turn on www.maimmunizations.org to Sign Up for the COVID Vaccine
By Christina Aiello

## Technologies
JavaScript
